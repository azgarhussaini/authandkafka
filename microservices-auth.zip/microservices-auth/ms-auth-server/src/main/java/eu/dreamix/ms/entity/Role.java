package eu.dreamix.ms.entity;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}