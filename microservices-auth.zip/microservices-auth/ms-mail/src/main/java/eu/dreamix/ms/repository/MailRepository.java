package eu.dreamix.ms.repository;

import eu.dreamix.ms.entity.Mail;
import org.springframework.data.repository.CrudRepository;


public interface MailRepository extends CrudRepository<Mail, Long> {

}